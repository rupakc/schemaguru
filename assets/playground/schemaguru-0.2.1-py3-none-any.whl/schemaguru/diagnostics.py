"""Diagnostics (layer 0): findings reported instead of raised (spec 20).

Codes are ``SGnnn``: ``SG1xx`` connection/catalog, ``SG2xx`` overlays, ``SG3xx`` measurement
and budget, ``SG4xx`` drafting/LLM, ``SG5xx`` scoping/rendering, ``SG6xx`` graph, ``SG7xx``
store, ``SG8xx`` server/agent. ``CODES`` is the single registry: a task that emits a new code
adds it here (code -> one-line meaning); ``docs/reference/diagnostics.md`` must equal this set.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any


class Severity(Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


CODES: Mapping[str, str] = MappingProxyType(
    {
        "SG101": "no catalog reader is registered for the requested dialect",
        "SG102": "the crawl skipped a catalog, schema, page or batch that failed to read",
        "SG104": "metadata SQL was refused: only a single SELECT/WITH/SHOW/DESCRIBE is allowed",
        "SG105": "the installed FactLang does not provide the metadata-SQL capability",
        "SG106": "a connection URL could not be opened (no FactLang connect, no built-in driver)",
        "SG107": "the object given as a connector is not one SchemaGuru can use, or its dialect "
        "cannot be told (ConfigError naming the accepted types)",
        "SG108": "an installed plugin (entry point schemaguru.<point>) failed to load and was "
        "skipped",
        "SG109": "a value cannot be inlined for a host without bind parameters (a backslash, NUL, "
        "line terminator, quote look-alike, non-scalar or non-finite value, a timestamp whose "
        "time zone cannot give its offset, or a ' on a dialect without a doubled-quote form "
        "such as BigQuery/Databricks/Spark/Hive); the probe is refused",
        "SG110": "the crawl stopped at Budget.crawl_bytes (billed metadata bytes, where the reader "
        "reports them); its checkpoint is kept and the next crawl resumes",
        "SG201": "overlay 'version' is missing or unsupported",
        "SG202": "overlay has an unknown key (a close match is suggested)",
        "SG203": "overlay reference does not resolve to anything in the store",
        "SG204": "overlay reference is ambiguous; the candidates are listed",
        "SG205": "overlay filter text is invalid",
        "SG206": "overlay waiver has no valid 'expires' date and is ignored",
        "SG207": "overlay waiver has expired and is ignored",
        "SG208": "overlay file is unreadable or an entry is malformed",
        "SG209": "dbt manifest is unreadable",
        "SG210": "a declared soft-delete filter does not match the catalog or the measured values; "
        "it is shown with a warning and never applied in SQL snippets",
        "SG211": "lineage could not be parsed for a definition; the reason is a fixed category "
        "(parse_error, too_large, timeout, unsupported_dialect, worker_died), never SQL text",
        "SG212": "column-level lineage needs the `lineage` extra (pip install "
        "'schemaguru[lineage]'); emitted at most once per crawl or import",
        "SG213": "a lineage ignore entry in an overlay matches no parsed link (the view was "
        "redefined, or the list is not exactly the parsed one); it hides nothing",
        "SG214": "the dbt manifest has no compiled_code (run `dbt compile`): only table-level "
        "lineage was imported",
        "SG215": "two dbt nodes write one relation with the same inputs but different details "
        "(for example another transform); the first by node id is kept",
        "SG301": "probe over the per-probe byte budget was not run (fact ERROR over_budget)",
        "SG302": "total measurement budget exhausted; the remaining tables stay queued",
        "SG303": "a measurement probe failed (fact ERROR for that subject only)",
        "SG304": "the installed FactLang does not provide a needed measurement capability",
        "SG305": "a table asked to be measured is not in the store (crawl it first)",
        "SG306": "a background measurement drain failed and is retried with backoff (one "
        "diagnostic per distinct error)",
        "SG401": "an LLM draft reply was invalid twice (schema or unknown names); fact ERROR",
        "SG402": "draft token budget exhausted; the remaining tables were not drafted",
        "SG403": "the LLM provider call failed; that call's tables get an ERROR draft fact",
        "SG404": "a table asked to be drafted is not in the store (crawl it first)",
        "SG405": "a drafted claim could not be checked (no verdict); the draft stays UNVERIFIED",
        "SG406": "a drafted soft-delete predicate is not a safe filter; it is never checked",
        "SG501": "a join snippet was not rendered (FactLang lacks render_join or refused the path)",
        "SG502": "filter text is invalid (FactLang parse_filter, or the syntax-only fallback)",
        "SG503": "filter text was checked for syntax only: FactLang lacks parse_filter",
        "SG504": "a context view exceeds its token budget: the always-on blocks do not fit",
        "SG505": "info: how many values or text spans the value policy masked in a view",
        "SG506": "a filter names a column matching several catalog columns that differ only in "
        "case: left unquoted",
        "SG507": "a sampling.per_glob entry matches no stored table (case-insensitive): its value "
        "mode applies to nothing; check the glob for a typo",
        "SG601": "a malformed join fact was skipped; only that graph edge is lost",
        "SG602": "a waypoint rule is malformed; the searches it governs are refused",
        "SG603": "a waypoint rule has more than 16 requirements; its searches are refused",
        "SG604": "a waypoint prohibition or requirement matches no edge or table in the graph",
        "SG605": "an identity chain cannot be compiled into a waypoint rule (it is not applied)",
        "SG701": "SQLite FTS5 is unavailable; search falls back to a slower LIKE scan",
        "SG702": "the store was written by a newer schema version than this library supports",
        "SG703": "the shared store is unavailable (refused, lost or pool exhausted; HTTP 503)",
        "SG704": "the shared store rejected the configured credentials: a configuration error, "
        "not an outage (HTTP 500)",
        "SG705": "the store does not implement the lineage index (a custom Store): downstream "
        "lineage is unavailable",
        "SG706": "a read-only store's search index is empty: search finds nothing until the store "
        "is opened read-write once (which rebuilds it)",
        "SG801": "guard refused the SQL: not a single read-only SELECT/WITH statement",
        "SG802": "guard refused the SQL: it reads a never-query table",
        "SG803": "an agent tool call was refused: unknown tool or invalid arguments",
        "SG804": "an agent tool failed unexpectedly (error type and a masked message returned)",
        "SG805": "server: missing or invalid bearer token (HTTP 401)",
        "SG806": "server: the route needs an admin token (HTTP 403)",
        "SG807": "server: invalid request (bad JSON, missing or wrong-typed parameter; HTTP 400)",
        "SG808": "server: the table or column named in the request is not in the store (HTTP 404)",
        "SG809": "server: a refresh is already running on this store (HTTP 409)",
        "SG810": "server: unexpected internal error; details are logged, not returned (HTTP 500)",
        "SG811": "server: no usable bearer tokens configured (missing, too short, or unknown role)",
        "SG812": "server: MCP over streamable HTTP needs the mcp extra, or its session manager "
        "is not running (HTTP 501 / 503)",
    }
)


@dataclass(frozen=True)
class Diagnostic:
    code: str
    severity: Severity
    message: str
    location: str | None = None
    hint: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
            "location": self.location,
            "hint": self.hint,
        }


class DiagnosticBag:
    """An ordered collection of diagnostics."""

    def __init__(self) -> None:
        self._items: list[Diagnostic] = []

    def add(self, diagnostic: Diagnostic) -> None:
        self._items.append(diagnostic)

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        self._items.extend(diagnostics)

    def errors(self) -> list[Diagnostic]:
        return [d for d in self._items if d.severity is Severity.ERROR]

    def __iter__(self) -> Iterator[Diagnostic]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def to_list(self) -> list[dict[str, Any]]:
        return [d.to_dict() for d in self._items]
