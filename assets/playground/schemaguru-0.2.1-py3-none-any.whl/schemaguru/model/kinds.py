"""Fact kinds: an open registry of :class:`KindSpec` (spec 4.3, 21)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, Literal

from schemaguru import plugins


@dataclass(frozen=True)
class KindSpec:
    """``identity_fields`` selects which payload keys define a fact's id.

    ``None`` = the whole value. A tuple (possibly empty) = only those keys, so measured numbers
    stay out of identity and re-measuring yields the same fact id.
    """

    name: str
    subject: Literal["table", "column", "join", "global"]
    meaning: bool
    expectation: bool
    identity_fields: tuple[str, ...] | None = None


_REGISTRY: dict[str, KindSpec] = {}


def register_fact_kind(spec: KindSpec, *, replace: bool = False) -> None:
    if spec.name in _REGISTRY and not replace:
        raise ValueError(f"fact kind already registered: {spec.name}")
    _REGISTRY[spec.name] = spec


def _plugin(name: str, obj: object) -> None:
    if not isinstance(obj, KindSpec):
        raise TypeError("a fact-kind plugin must be a KindSpec")
    register_fact_kind(obj)


def get_kind(name: str) -> KindSpec:
    if name not in _REGISTRY:  # entry points ``schemaguru.fact_kinds`` (spec 21), once
        plugins.discover("fact_kinds", _plugin)
    try:
        return _REGISTRY[name]
    except KeyError:
        raise KeyError(f"unknown fact kind: {name}") from None


def _k(
    name: str,
    subject: Literal["table", "column", "join", "global"],
    *,
    meaning: bool = False,
    expectation: bool = False,
    identity: tuple[str, ...] | None = None,
) -> KindSpec:
    spec = KindSpec(name, subject, meaning, expectation, identity)
    register_fact_kind(spec)
    return spec


class FactKind:
    """The built-in kinds (spec 4.3 table)."""

    DESCRIPTION: ClassVar[KindSpec] = _k("DESCRIPTION", "table", meaning=True)
    USE_CASES: ClassVar[KindSpec] = _k("USE_CASES", "table", meaning=True)
    ENTITY_TYPE: ClassVar[KindSpec] = _k("ENTITY_TYPE", "table", meaning=True)
    PRIMARY_KEY: ClassVar[KindSpec] = _k(
        "PRIMARY_KEY", "table", expectation=True, identity=("columns",)
    )
    JOIN: ClassVar[KindSpec] = _k("JOIN", "join", expectation=True, identity=())
    VALUES: ClassVar[KindSpec] = _k(
        "VALUES", "column", expectation=True, identity=("case_sensitive", "split")
    )
    NULL_RATE: ClassVar[KindSpec] = _k("NULL_RATE", "column", identity=())
    ROW_COUNT: ClassVar[KindSpec] = _k("ROW_COUNT", "table", identity=())
    DISTINCT: ClassVar[KindSpec] = _k("DISTINCT", "column", identity=())
    FRESHNESS: ClassVar[KindSpec] = _k("FRESHNESS", "table", identity=("column",))
    TYPE_NOTE: ClassVar[KindSpec] = _k("TYPE_NOTE", "column", identity=("stored_as", "means"))
    SOFT_DELETE: ClassVar[KindSpec] = _k(
        "SOFT_DELETE", "table", expectation=True, identity=("predicate",)
    )
    PII: ClassVar[KindSpec] = _k("PII", "column", identity=("category",))
    PITFALL: ClassVar[KindSpec] = _k("PITFALL", "table", meaning=True)
    GLOSSARY: ClassVar[KindSpec] = _k("GLOSSARY", "global", meaning=True)
    METRIC: ClassVar[KindSpec] = _k("METRIC", "global")
    NEVER_QUERY: ClassVar[KindSpec] = _k("NEVER_QUERY", "table")
    WAYPOINT_RULE: ClassVar[KindSpec] = _k("WAYPOINT_RULE", "global")
    # Lineage (0.2.0 spec 4.1). ``ignore`` is identity so a human ignore entry and a replace entry
    # with the same list never share an id; ``source`` is not (an overlay line number would move
    # ids whenever lines above it move).
    LINEAGE: ClassVar[KindSpec] = _k("LINEAGE", "table", identity=("upstream", "ignore"))
    COLUMN_LINEAGE: ClassVar[KindSpec] = _k(
        "COLUMN_LINEAGE", "column", identity=("inputs", "ignore")
    )


# Declared or parsed, never measured or verified (0.2.0 spec 4.1).
LINEAGE_KINDS: frozenset[str] = frozenset({"LINEAGE", "COLUMN_LINEAGE"})
